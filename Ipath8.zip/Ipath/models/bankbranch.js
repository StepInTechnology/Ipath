/* jshint indent: 2 */

module.exports = function(sequelize, DataTypes) {
  return sequelize.define('bankbranch', {
    id: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    bankId: {
      type: DataTypes.INTEGER(11),
      allowNull: false
    },
    branchName: {
      type: DataTypes.STRING(200),
      allowNull: false
    },
    ifscCode: {
      type: DataTypes.INTEGER(20),
      allowNull: false
    }
  }, {
    tableName: 'bankbranch'
  });
};
