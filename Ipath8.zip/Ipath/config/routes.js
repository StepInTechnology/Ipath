var HomeController = require('../app/controllers/HomeController');
var ProductController = require('../app/controllers/ProductController');
var CompanyController = require('../app/controllers/CompanyController');
var CustomerController = require('../app/controllers/CustomerController');
var SettingController = require('../app/controllers/SettingController');


//you can include all your controllers

module.exports = function (app) {


    app.get('/', HomeController.index);//home
  
    //-----------------Routers For Product---------------------------------------
    app.get('/Prduct/product_list/', ProductController.product_list);//product_list
    app.get('/Product/product_add/', ProductController.product_add);//product_add


        //-----------------Routers For Company---------------------------------------
     /*   app.get('/Company/company_profile_list/', CompanyController.company_profile_list);//company_profile_list
        app.get('/Company/company_profile_add/', CompanyController.company_profile_add);//company_profile_add


        app.get('/Company/branch_info_list/', CompanyController.branch_info_list);//branch_info_list
        app.get('/Company/branch_info_add/', CompanyController.branch_info_add);//branch_info_add



        //-----------------Routers For Customers---------------------------------------
        app.get('/Customer/customer_details_list/', CustomerController.customer_details_list);//customer_details_list
        app.get('/Customer/customer_details_add/',  CustomerController.customer_details_add);//customer_details_add


        app.get('/Customer/customer_order_list/', CustomerController.customer_order_list);//customer_order_list
        app.get('/Customer/customer_order_add/',    CustomerController.customer_order_add);//customer_order_add
*/

        //-----------------Routers For Setting---------------------------------------
        app.get('/Setting/supplier_list/', SettingController.supplier_list);//supplier_list
        app.get('/Setting/supplier_add/', SettingController.supplier_add);//supplier_add
    
        app.get('/Setting/category_master/', SettingController.category_master);//category_master



        app.get('/Setting/bank_state/', SettingController.bank_state);//bank_state
        app.get('/Setting/bank_state/:id', SettingController.bank_state);//bank_state
        app.post('/Setting/bank_state_add/', SettingController.bank_state_add);//bank_state 
        app.get('/Setting/bank_state_destroy/:id', SettingController.bank_state_destroy);



        app.get('/Setting/bank_branch_destroy/:id', SettingController.bank_branch_destroy);
        app.get('/Setting/bank_branch/', SettingController.bank_branch);//bank_branch
        app.post('/Setting/bank_branch_add/', SettingController.bank_branch_add);//bank_branch_add




        app.post('/Setting/city/', SettingController.city);//city
        app.post('/Setting/locality/', SettingController.locality);//locality

        app.get('/Setting/city/', SettingController.city);//city
        app.get('/Setting/locality/', SettingController.locality);//locality
      
    
}

