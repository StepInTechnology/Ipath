'use strict';
/*
module.exports = (sequelize, DataTypes) => {
  const Bank = sequelize.define('Bank', {
    bank_name: DataTypes.STRING
  }, {});
  Bank.associate = function(models) {
    // associations can be defined here
  };
  return Bank;
};*/
var Bank = require('./bank');
var Sequelize = require("./index");

const sequelize = require('sequelize');

var BankBranch = Sequelize.define('bankbranches', {
    id: {
		type: sequelize.BIGINT(11),
		autoIncrement: true,
		allowNull: false,
		primaryKey: true
	},
	branchName: {
		type: sequelize.STRING(100),
		allowNull: false,
		
  },
  ifscCode: {
		type: sequelize.STRING(100),
		allowNull: false,
		
  },
  isDelete: {
		type: sequelize.INTEGER(10),
    allowNull: true,
    defaultValue:0
		
  },

}, 
);
BankBranch.belongsTo(Bank);
//Sequelize.sync();
module.exports = BankBranch;