'use strict';
/*
module.exports = (sequelize, DataTypes) => {
  const Bank = sequelize.define('Bank', {
    bank_name: DataTypes.STRING
  }, {});
  Bank.associate = function(models) {
    // associations can be defined here
  };
  return Bank;
};*/

var Sequelize = require("./index");

const sequelize = require('sequelize');

var Bank = Sequelize.define('banks', {
    id: {
		type: sequelize.BIGINT(11),
		autoIncrement: true,
		allowNull: false,
		primaryKey: true
	},
	bank_name: {
		type: sequelize.STRING(100),
		allowNull: false,
		
  },
  isDelete: {
		type: sequelize.INTEGER(10),
    allowNull: true,
    defaultValue:0
		
	},

	
});
//Sequelize.sync();
module.exports = Bank;