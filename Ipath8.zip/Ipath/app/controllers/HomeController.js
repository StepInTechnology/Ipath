//var numeral = require('numeral');
//var bcrypt = require('bcrypt-nodejs');
//var dateFormat = require('dateformat');



exports.index = function(req, res) {
	
	res.render('./Home/index.ejs', {
		
		//error : req.flash("error"),
	//	success: req.flash("success"),
	//	session:req.session,
	
	 });
	
	 
}







    
