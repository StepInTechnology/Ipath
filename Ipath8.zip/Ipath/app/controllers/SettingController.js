
const fs = require('fs');
var async = require('async')
var Bank = require('../models/bank');
var AppController = require("./AppController.js");
var BankBranch = require('../models/bankBranch');
exports.supplier_list = function(req, res) {
	
	
	res.render('./Setting/supplier_list.ejs', {
		
		//error : req.flash("error"),
	//	success: req.flash("success"),
	//	session:req.session, 
	
	 });
}
exports.supplier_add = function(req, res) {
	
	res.render('./Setting/supplier_add.ejs', {
		
		//error : req.flash("error"),
	//	success: req.flash("success"),
	//	session:req.session,
	
	 });
}
exports.category_master = function(req, res) {
	
	res.render('./Setting/category_master.ejs', {
		
		//error : req.flash("error"),
	//	success: req.flash("success"),
	//	session:req.session,
	
	 });
}










exports.bank_state_add = function(req, res) {
	if(req.body.bank_name && req.body.id==''){

		
		Bank.findOrCreate({where: {bank_name: req.body.bank_name,isDelete:0}, defaults: req.body})
		.spread((user, created) => {
		
			console.log(req.body)
			res.redirect('/Setting/bank_state');

		})
	}
	if(req.body.bank_name && req.body.id!=''){
		updateValues=req.body;
		Bank.update(updateValues, { where: { id: req.body.id } }).then((result) => {
			// here your result is simply an array with number of affected rows
			console.log(result);
			res.redirect('/Setting/bank_state');
			// [ 1 ]
		});
	}


}
exports.bank_state_destroy = function(req, res) {
	if(req.params.id){

		Bank.update({'isDelete':1}, { where: { id: req.params.id } }).then((result) => {
			// here your result is simply an array with number of affected rows
			console.log(result);
			res.redirect('/Setting/bank_state');
			// [ 1 ]
		});

	}
}
exports.bank_state = function(req, res) {
	async.parallel([
		function(callback) {
			if(req.params.id){
		
				Bank.findOne({where: {id: req.params.id}}).then(bank => { 
					
					callback(null, bank);
				});
			}
			else 
			callback(null, 1);
		  },
		  function(callback) {
			Bank.findAll({where: {isDelete: 0}}).then(bank => {
				callback(null, bank);
				
			});
		},
	],function(err, results) {
		console.log(JSON.stringify(results));
		res.render('./Setting/bank_state.ejs', {bank_list:results[1],bank_details:results[0]})
	  })
	
}




exports.bank_branch_add = function(req, res) {
	//console.log(JSON.stringify(req.body));
	if(req.body.bankId && req.body.id==''){
		
		BankBranch.findOrCreate({where: {bankId: req.body.bankId,branchName: req.body.branchName,isDelete:0}, defaults: req.body})
		.spread((user, created) => {
		
			//console.log(req.body)
			res.redirect('/Setting/bank_branch');

		})
	}
	if(req.body.bank_name && req.body.id!=''){
		updateValues=req.body;
		Bank.update(updateValues, { where: { id: req.body.id } }).then((result) => {
			// here your result is simply an array with number of affected rows
			//console.log(result);
			res.redirect('/Setting/bank_state');
			// [ 1 ]
		});
	}
	else{
		//res.redirect('/Setting/bank_state');
	}



}
exports.bank_branch_destroy = function(req, res) {
	if(req.params.id){

		BankBranch.update({'isDelete':1}, { where: { id: req.params.id } }).then((result) => {
			// here your result is simply an array with number of affected rows
			console.log(result);
			res.redirect('/Setting/bank_branch');
			// [ 1 ]
		});

	}
}
exports.bank_branch = function(req, res) {
	async.parallel([
		function(callback) {
			Bank.findAll({where: {isDelete: 0}}).then(bank => {
				callback(null, bank);
				
			});
		  },
		  function(callback) {
			
			
			BankBranch.findAll({where: {isDelete: 0}, include: [
				{ model: Bank, attributes: ["id","bank_name"] },
			
			],}).then(bankBranch => {
				callback(null, bankBranch);
				
			});
		  },
	],function(err, results) {
		//console.log(JSON.stringify(results[1]));
		res.render('./Setting/bank_branch.ejs', {bank:results[0],branch_list:results[1]})
	  })
}





exports.city = function(req, res) {
	
	res.render('./Setting/city.ejs', {
		
		//error : req.flash("error"),
	//	success: req.flash("success"),
	//	session:req.session,
	
	 });
}
exports.locality = function(req, res) {
	
	res.render('./Setting/locality.ejs', {
		
	//error : req.flash("error"),
	//	success: req.flash("success"),
	//	session:req.session,
	
	 });
}
