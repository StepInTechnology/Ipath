

module.exports = {
    getBank: function(res) {
        
        var Bank = require('../models/bank');
         Bank
        .findAll({where: {is_delete: 0}})
        .then(function(bank){
            callback(null, bank);
         });
        
       // console.log(someRows);
        
    },
    getBank2: function() {
        return 5
    }
};