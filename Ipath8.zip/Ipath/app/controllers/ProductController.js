exports.product_list = function(req, res) {
	
	res.render('./Product/product_list.ejs', {
		
		//error : req.flash("error"),
	//	success: req.flash("success"),
	//	session:req.session,
	
	 });
}
exports.product_add = function(req, res) {
	
	res.render('./Product/product_add.ejs', {
		
		//error : req.flash("error"),
	//	success: req.flash("success"),
	//	session:req.session,
	
	 });
}
